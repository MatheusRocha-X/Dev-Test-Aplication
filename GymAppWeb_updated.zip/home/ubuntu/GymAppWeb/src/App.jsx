import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx';
import { 
  Home, 
  Dumbbell, 
  Activity, 
  TrendingUp, 
  Plus, 
  Play, 
  Trash2, 
  Edit, 
  Trophy,
  Timer,
  Target,
  Droplets,
  Bell,
  Clock,
  CheckCircle
} from 'lucide-react';
import './App.css';

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [workouts, setWorkouts] = useState([]);
  const [exercises, setExercises] = useState([]);
  const [workoutHistory, setWorkoutHistory] = useState([]);
  const [currentWorkout, setCurrentWorkout] = useState(null);
  const [isWorkoutActive, setIsWorkoutActive] = useState(false);
  
  // Estados para lembrete de água
  const [waterSettings, setWaterSettings] = useState({
    dailyGoal: 8, // copos por dia
    reminderInterval: 60, // minutos
    isEnabled: false,
    cupSize: 250 // ml
  });
  const [waterIntake, setWaterIntake] = useState([]);
  const [waterReminders, setWaterReminders] = useState([]);
  const [lastWaterTime, setLastWaterTime] = useState(null);

  // Carregar dados do localStorage
  useEffect(() => {
    const savedWorkouts = localStorage.getItem('gymapp-workouts');
    const savedExercises = localStorage.getItem('gymapp-exercises');
    const savedHistory = localStorage.getItem('gymapp-history');
    const savedWaterSettings = localStorage.getItem('gymapp-water-settings');
    const savedWaterIntake = localStorage.getItem('gymapp-water-intake');

    if (savedWorkouts) setWorkouts(JSON.parse(savedWorkouts));
    if (savedExercises) setExercises(JSON.parse(savedExercises));
    if (savedHistory) setWorkoutHistory(JSON.parse(savedHistory));
    if (savedWaterSettings) setWaterSettings(JSON.parse(savedWaterSettings));
    if (savedWaterIntake) setWaterIntake(JSON.parse(savedWaterIntake));

    // Carregar exercícios padrão se não houver nenhum
    if (!savedExercises) {
      const defaultExercises = [
        {
          id: 1,
          name: 'Supino Reto',
          category: 'Peito',
          description: 'Exercício básico para desenvolvimento do peitoral',
          muscleGroups: ['Peitoral', 'Tríceps', 'Deltóide anterior'],
          equipment: 'Barra',
        },
        {
          id: 2,
          name: 'Agachamento',
          category: 'Pernas',
          description: 'Exercício fundamental para pernas e glúteos',
          muscleGroups: ['Quadríceps', 'Glúteos', 'Isquiotibiais'],
          equipment: 'Barra',
        },
        {
          id: 3,
          name: 'Puxada na Polia',
          category: 'Costas',
          description: 'Exercício para desenvolvimento das costas',
          muscleGroups: ['Latíssimo do dorso', 'Bíceps', 'Rombóides'],
          equipment: 'Polia',
        },
      ];
      setExercises(defaultExercises);
      localStorage.setItem('gymapp-exercises', JSON.stringify(defaultExercises));
    }
  }, []);

  // Salvar dados no localStorage
  useEffect(() => {
    localStorage.setItem('gymapp-workouts', JSON.stringify(workouts));
  }, [workouts]);

  useEffect(() => {
    localStorage.setItem('gymapp-exercises', JSON.stringify(exercises));
  }, [exercises]);

  useEffect(() => {
    localStorage.setItem('gymapp-history', JSON.stringify(workoutHistory));
  }, [workoutHistory]);

  useEffect(() => {
    localStorage.setItem('gymapp-water-settings', JSON.stringify(waterSettings));
  }, [waterSettings]);

  useEffect(() => {
    localStorage.setItem('gymapp-water-intake', JSON.stringify(waterIntake));
  }, [waterIntake]);

  // Sistema de notificações de água
  useEffect(() => {
    let interval;
    
    if (waterSettings.isEnabled && waterSettings.reminderInterval > 0) {
      // Solicitar permissão para notificações
      if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
      }
      
      interval = setInterval(() => {
        const now = new Date();
        const todayIntake = waterIntake.filter(intake => 
          new Date(intake.timestamp).toDateString() === now.toDateString()
        );
        
        if (todayIntake.length < waterSettings.dailyGoal) {
          // Mostrar notificação
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('💧 Hora de beber água!', {
              body: `Você já bebeu ${todayIntake.length} de ${waterSettings.dailyGoal} copos hoje.`,
              icon: '/favicon.ico'
            });
          }
          
          // Adicionar lembrete visual
          setWaterReminders(prev => [...prev, {
            id: Date.now(),
            timestamp: now.toISOString(),
            message: 'Hora de beber água!'
          }]);
        }
      }, waterSettings.reminderInterval * 60 * 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [waterSettings, waterIntake]);

  // Função para registrar consumo de água
  const drinkWater = () => {
    const now = new Date();
    setWaterIntake(prev => [...prev, {
      id: Date.now(),
      timestamp: now.toISOString(),
      amount: waterSettings.cupSize
    }]);
    setLastWaterTime(now);
    
    // Remover lembretes pendentes
    setWaterReminders([]);
  };

  // Componente da tela inicial
  const HomeScreen = () => {
    const todayWorkouts = workoutHistory.filter(w => 
      new Date(w.date).toDateString() === new Date().toDateString()
    );

    const thisWeekWorkouts = workoutHistory.filter(w => {
      const workoutDate = new Date(w.date);
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return workoutDate >= weekAgo;
    });

    const todayWater = waterIntake.filter(w => 
      new Date(w.timestamp).toDateString() === new Date().toDateString()
    );

    return (
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-blue-600 mb-2">Bem-vindo ao GymApp!</h1>
          <p className="text-gray-600">
            {todayWorkouts.length > 0 ? 'Você já treinou hoje! 💪' : 'Pronto para treinar hoje?'}
          </p>
        </div>

        {/* Lembretes de água */}
        {waterReminders.length > 0 && (
          <Card className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Droplets className="h-6 w-6" />
                  <span className="font-semibold">💧 Hora de beber água!</span>
                </div>
                <Button 
                  className="bg-white text-blue-600 hover:bg-gray-100"
                  size="sm"
                  onClick={drinkWater}
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Bebi!
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Botão de treino rápido */}
        <Card className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
          <CardContent className="p-6">
            <Button 
              className="w-full bg-white text-orange-600 hover:bg-gray-100"
              size="lg"
              onClick={() => {
                if (workouts.length > 0) {
                  setCurrentWorkout(workouts[0]);
                  setActiveTab('workout-detail');
                } else {
                  alert('Crie seu primeiro treino na aba Treinos!');
                }
              }}
            >
              <Play className="mr-2 h-5 w-5" />
              Iniciar Treino Rápido
            </Button>
          </CardContent>
        </Card>

        {/* Estatísticas */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{todayWorkouts.length}</div>
              <div className="text-sm text-gray-600">Treinos Hoje</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{thisWeekWorkouts.length}</div>
              <div className="text-sm text-gray-600">Esta Semana</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{workouts.length}</div>
              <div className="text-sm text-gray-600">Treinos Criados</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-cyan-600">{todayWater.length}/{waterSettings.dailyGoal}</div>
              <div className="text-sm text-gray-600">Água Hoje</div>
            </CardContent>
          </Card>
        </div>

        {/* Treinos recentes */}
        <Card>
          <CardHeader>
            <CardTitle>Treinos Recentes</CardTitle>
          </CardHeader>
          <CardContent>
            {workouts.length > 0 ? (
              <div className="space-y-3">
                {workouts.slice(-3).reverse().map((workout) => (
                  <div key={workout.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h3 className="font-semibold">{workout.name}</h3>
                      <p className="text-sm text-gray-600">{workout.exercises?.length || 0} exercícios</p>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setCurrentWorkout(workout);
                        setActiveTab('workout-detail');
                      }}
                    >
                      Ver Detalhes
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Dumbbell className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600 mb-4">Nenhum treino criado ainda</p>
                <Button onClick={() => setActiveTab('workouts')}>
                  Criar Primeiro Treino
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  // Componente da tela de água
  const WaterScreen = () => {
    const todayWater = waterIntake.filter(w => 
      new Date(w.timestamp).toDateString() === new Date().toDateString()
    );

    const progress = (todayWater.length / waterSettings.dailyGoal) * 100;

    const getNextReminderTime = () => {
      if (!waterSettings.isEnabled || !lastWaterTime) return null;
      const next = new Date(lastWaterTime);
      next.setMinutes(next.getMinutes() + waterSettings.reminderInterval);
      return next;
    };

    const nextReminder = getNextReminderTime();

    return (
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-blue-600 mb-2">💧 Lembrete de Água</h1>
          <p className="text-gray-600">Mantenha-se hidratado durante o dia!</p>
        </div>

        {/* Progresso diário */}
        <Card>
          <CardContent className="p-6 text-center">
            <div className="mb-4">
              <div className="text-4xl font-bold text-blue-600 mb-2">
                {todayWater.length}/{waterSettings.dailyGoal}
              </div>
              <div className="text-gray-600">Copos de água hoje</div>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
              <div 
                className="bg-blue-500 h-4 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(progress, 100)}%` }}
              ></div>
            </div>
            
            <div className="text-sm text-gray-500 mb-4">
              {progress >= 100 ? '🎉 Meta diária atingida!' : `${Math.round(progress)}% da meta diária`}
            </div>

            <Button 
              onClick={drinkWater}
              size="lg"
              className="bg-blue-500 hover:bg-blue-600"
            >
              <Droplets className="mr-2 h-5 w-5" />
              Bebi um copo! (+{waterSettings.cupSize}ml)
            </Button>
          </CardContent>
        </Card>

        {/* Configurações */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Configurações de Lembrete
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Ativar lembretes</Label>
              <Button
                variant={waterSettings.isEnabled ? "default" : "outline"}
                size="sm"
                onClick={() => setWaterSettings(prev => ({ ...prev, isEnabled: !prev.isEnabled }))}
              >
                {waterSettings.isEnabled ? 'Ativado' : 'Desativado'}
              </Button>
            </div>

            <div>
              <Label htmlFor="dailyGoal">Meta diária (copos)</Label>
              <Input
                id="dailyGoal"
                type="number"
                value={waterSettings.dailyGoal}
                onChange={(e) => setWaterSettings(prev => ({ 
                  ...prev, 
                  dailyGoal: parseInt(e.target.value) || 8 
                }))}
                min="1"
                max="20"
              />
            </div>

            <div>
              <Label htmlFor="reminderInterval">Intervalo de lembrete (minutos)</Label>
              <Select 
                value={waterSettings.reminderInterval.toString()} 
                onValueChange={(value) => setWaterSettings(prev => ({ 
                  ...prev, 
                  reminderInterval: parseInt(value) 
                }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 minutos</SelectItem>
                  <SelectItem value="30">30 minutos</SelectItem>
                  <SelectItem value="45">45 minutos</SelectItem>
                  <SelectItem value="60">1 hora</SelectItem>
                  <SelectItem value="90">1h 30min</SelectItem>
                  <SelectItem value="120">2 horas</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="cupSize">Tamanho do copo (ml)</Label>
              <Select 
                value={waterSettings.cupSize.toString()} 
                onValueChange={(value) => setWaterSettings(prev => ({ 
                  ...prev, 
                  cupSize: parseInt(value) 
                }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="200">200ml (copo pequeno)</SelectItem>
                  <SelectItem value="250">250ml (copo médio)</SelectItem>
                  <SelectItem value="300">300ml (copo grande)</SelectItem>
                  <SelectItem value="500">500ml (garrafa pequena)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {waterSettings.isEnabled && nextReminder && (
              <div className="p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 text-blue-700">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">
                    Próximo lembrete: {nextReminder.toLocaleTimeString('pt-BR', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Histórico do dia */}
        <Card>
          <CardHeader>
            <CardTitle>Histórico de Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            {todayWater.length > 0 ? (
              <div className="space-y-2">
                {todayWater.reverse().map((intake, index) => (
                  <div key={intake.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div className="flex items-center gap-2">
                      <Droplets className="h-4 w-4 text-blue-500" />
                      <span className="text-sm">Copo {todayWater.length - index}</span>
                    </div>
                    <div className="text-sm text-gray-500">
                      {new Date(intake.timestamp).toLocaleTimeString('pt-BR', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-gray-500">
                <Droplets className="mx-auto h-8 w-8 mb-2 opacity-50" />
                <p>Nenhum copo registrado hoje</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  // Componente da tela de treinos
  const WorkoutsScreen = () => {
    const [showAddWorkout, setShowAddWorkout] = useState(false);
    const [editingWorkout, setEditingWorkout] = useState(null);

    const deleteWorkout = (id) => {
      if (confirm('Tem certeza que deseja excluir este treino?')) {
        setWorkouts(workouts.filter(w => w.id !== id));
      }
    };

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Meus Treinos</h1>
          <Dialog open={showAddWorkout} onOpenChange={setShowAddWorkout}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Treino
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingWorkout ? 'Editar Treino' : 'Novo Treino'}
                </DialogTitle>
              </DialogHeader>
              <AddWorkoutForm 
                workout={editingWorkout}
                exercises={exercises}
                onSave={(workout) => {
                  if (editingWorkout) {
                    setWorkouts(workouts.map(w => w.id === editingWorkout.id ? workout : w));
                  } else {
                    setWorkouts([...workouts, { ...workout, id: Date.now() }]);
                  }
                  setShowAddWorkout(false);
                  setEditingWorkout(null);
                }}
                onCancel={() => {
                  setShowAddWorkout(false);
                  setEditingWorkout(null);
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        {workouts.length > 0 ? (
          <div className="grid gap-4">
            {workouts.map((workout) => (
              <Card key={workout.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-2">{workout.name}</h3>
                      <p className="text-gray-600 mb-3">{workout.description}</p>
                      <div className="flex gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Dumbbell className="h-4 w-4" />
                          {workout.exercises?.length || 0} exercícios
                        </span>
                        <span className="flex items-center gap-1">
                          <Timer className="h-4 w-4" />
                          {workout.estimatedDuration || 30} min
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingWorkout(workout);
                          setShowAddWorkout(true);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deleteWorkout(workout.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => {
                          setCurrentWorkout(workout);
                          setActiveTab('workout-detail');
                        }}
                      >
                        <Play className="mr-2 h-4 w-4" />
                        Iniciar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Dumbbell className="mx-auto h-16 w-16 text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum treino criado</h3>
              <p className="text-gray-600 mb-4">Crie seu primeiro treino para começar!</p>
              <Button onClick={() => setShowAddWorkout(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Criar Primeiro Treino
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  // Componente para adicionar/editar treino
  const AddWorkoutForm = ({ workout, exercises, onSave, onCancel }) => {
    const [name, setName] = useState(workout?.name || '');
    const [description, setDescription] = useState(workout?.description || '');
    const [selectedExercises, setSelectedExercises] = useState(workout?.exercises || []);
    const [estimatedDuration, setEstimatedDuration] = useState(workout?.estimatedDuration || 30);

    const addExercise = (exercise) => {
      setSelectedExercises([...selectedExercises, {
        ...exercise,
        targetSets: 3,
        targetReps: 12,
        restTime: 60
      }]);
    };

    const removeExercise = (index) => {
      setSelectedExercises(selectedExercises.filter((_, i) => i !== index));
    };

    const handleSave = () => {
      if (!name.trim()) {
        alert('Digite um nome para o treino');
        return;
      }
      if (selectedExercises.length === 0) {
        alert('Adicione pelo menos um exercício');
        return;
      }

      onSave({
        name: name.trim(),
        description: description.trim(),
        exercises: selectedExercises,
        estimatedDuration,
        createdAt: workout?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    };

    return (
      <div className="space-y-4">
        <div>
          <Label htmlFor="name">Nome do Treino</Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: Treino de Peito e Tríceps"
          />
        </div>

        <div>
          <Label htmlFor="description">Descrição</Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Descreva o objetivo deste treino..."
          />
        </div>

        <div>
          <Label htmlFor="duration">Duração Estimada (minutos)</Label>
          <Input
            id="duration"
            type="number"
            value={estimatedDuration}
            onChange={(e) => setEstimatedDuration(parseInt(e.target.value) || 30)}
          />
        </div>

        <div>
          <Label>Exercícios ({selectedExercises.length})</Label>
          <div className="mt-2 space-y-2">
            {selectedExercises.map((exercise, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded">
                <div>
                  <span className="font-medium">{exercise.name}</span>
                  <span className="text-sm text-gray-500 ml-2">({exercise.category})</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeExercise(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>

          <div className="mt-4">
            <Label>Adicionar Exercício</Label>
            <Select onValueChange={(value) => {
              const exercise = exercises.find(e => e.id.toString() === value);
              if (exercise && !selectedExercises.find(se => se.id === exercise.id)) {
                addExercise(exercise);
              }
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um exercício" />
              </SelectTrigger>
              <SelectContent>
                {exercises
                  .filter(e => !selectedExercises.find(se => se.id === e.id))
                  .map((exercise) => (
                    <SelectItem key={exercise.id} value={exercise.id.toString()}>
                      {exercise.name} ({exercise.category})
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex gap-2 pt-4">
          <Button variant="outline" onClick={onCancel} className="flex-1">
            Cancelar
          </Button>
          <Button onClick={handleSave} className="flex-1">
            {workout ? 'Atualizar' : 'Criar'} Treino
          </Button>
        </div>
      </div>
    );
  };

  // Componente da tela de exercícios
  const ExercisesScreen = () => {
    const [showAddExercise, setShowAddExercise] = useState(false);
    const [editingExercise, setEditingExercise] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('all');

    const categories = ['all', 'Peito', 'Costas', 'Pernas', 'Ombros', 'Braços', 'Abdômen', 'Cardio'];

    const filteredExercises = exercises.filter(exercise => {
      const matchesSearch = exercise.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           exercise.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || exercise.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });

    const deleteExercise = (id) => {
      if (confirm('Tem certeza que deseja excluir este exercício?')) {
        setExercises(exercises.filter(e => e.id !== id));
      }
    };

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Exercícios</h1>
          <Dialog open={showAddExercise} onOpenChange={setShowAddExercise}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Exercício
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingExercise ? 'Editar Exercício' : 'Novo Exercício'}
                </DialogTitle>
              </DialogHeader>
              <AddExerciseForm 
                exercise={editingExercise}
                onSave={(exercise) => {
                  if (editingExercise) {
                    setExercises(exercises.map(e => e.id === editingExercise.id ? exercise : e));
                  } else {
                    setExercises([...exercises, { ...exercise, id: Date.now() }]);
                  }
                  setShowAddExercise(false);
                  setEditingExercise(null);
                }}
                onCancel={() => {
                  setShowAddExercise(false);
                  setEditingExercise(null);
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Filtros */}
        <div className="flex gap-4">
          <div className="flex-1">
            <Input
              placeholder="Buscar exercícios..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as categorias</SelectItem>
              {categories.slice(1).map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Lista de exercícios */}
        {filteredExercises.length > 0 ? (
          <div className="grid gap-4">
            {filteredExercises.map((exercise) => (
              <Card key={exercise.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-lg font-semibold">{exercise.name}</h3>
                        <Badge variant="secondary">{exercise.category}</Badge>
                      </div>
                      <p className="text-gray-600 mb-3">{exercise.description}</p>
                      <div className="flex flex-wrap gap-1 mb-2">
                        {exercise.muscleGroups?.map((muscle, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {muscle}
                          </Badge>
                        ))}
                      </div>
                      {exercise.equipment && (
                        <p className="text-sm text-gray-500">
                          <Dumbbell className="inline h-4 w-4 mr-1" />
                          {exercise.equipment}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingExercise(exercise);
                          setShowAddExercise(true);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deleteExercise(exercise.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Activity className="mx-auto h-16 w-16 text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum exercício encontrado</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || selectedCategory !== 'all' 
                  ? 'Tente ajustar os filtros de busca'
                  : 'Crie seu primeiro exercício personalizado!'
                }
              </p>
              {!searchTerm && selectedCategory === 'all' && (
                <Button onClick={() => setShowAddExercise(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Criar Exercício
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  // Componente para adicionar/editar exercício
  const AddExerciseForm = ({ exercise, onSave, onCancel }) => {
    const [name, setName] = useState(exercise?.name || '');
    const [description, setDescription] = useState(exercise?.description || '');
    const [category, setCategory] = useState(exercise?.category || '');
    const [muscleGroups, setMuscleGroups] = useState(exercise?.muscleGroups || []);
    const [equipment, setEquipment] = useState(exercise?.equipment || '');

    const categories = ['Peito', 'Costas', 'Pernas', 'Ombros', 'Braços', 'Abdômen', 'Cardio'];
    const availableMuscleGroups = [
      'Peitoral', 'Latíssimo do dorso', 'Trapézio', 'Rombóides', 'Deltóides',
      'Bíceps', 'Tríceps', 'Antebraços', 'Quadríceps', 'Isquiotibiais',
      'Glúteos', 'Panturrilhas', 'Abdômen', 'Oblíquos', 'Core'
    ];

    const toggleMuscleGroup = (muscle) => {
      if (muscleGroups.includes(muscle)) {
        setMuscleGroups(muscleGroups.filter(m => m !== muscle));
      } else {
        setMuscleGroups([...muscleGroups, muscle]);
      }
    };

    const handleSave = () => {
      if (!name.trim()) {
        alert('Digite um nome para o exercício');
        return;
      }
      if (!category) {
        alert('Selecione uma categoria');
        return;
      }
      if (muscleGroups.length === 0) {
        alert('Selecione pelo menos um grupo muscular');
        return;
      }

      onSave({
        name: name.trim(),
        description: description.trim(),
        category,
        muscleGroups,
        equipment: equipment.trim(),
        createdAt: exercise?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    };

    return (
      <div className="space-y-4">
        <div>
          <Label htmlFor="name">Nome do Exercício</Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: Supino Reto"
          />
        </div>

        <div>
          <Label htmlFor="description">Descrição</Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Descreva como executar o exercício..."
          />
        </div>

        <div>
          <Label>Categoria</Label>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione uma categoria" />
            </SelectTrigger>
            <SelectContent>
              {categories.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Grupos Musculares ({muscleGroups.length} selecionados)</Label>
          <div className="grid grid-cols-3 gap-2 mt-2">
            {availableMuscleGroups.map(muscle => (
              <Button
                key={muscle}
                variant={muscleGroups.includes(muscle) ? "default" : "outline"}
                size="sm"
                onClick={() => toggleMuscleGroup(muscle)}
                className="text-xs"
              >
                {muscle}
              </Button>
            ))}
          </div>
        </div>

        <div>
          <Label htmlFor="equipment">Equipamento</Label>
          <Input
            id="equipment"
            value={equipment}
            onChange={(e) => setEquipment(e.target.value)}
            placeholder="Ex: Barra, Halteres, Máquina..."
          />
        </div>

        <div className="flex gap-2 pt-4">
          <Button variant="outline" onClick={onCancel} className="flex-1">
            Cancelar
          </Button>
          <Button onClick={handleSave} className="flex-1">
            {exercise ? 'Atualizar' : 'Criar'} Exercício
          </Button>
        </div>
      </div>
    );
  };

  // Componente da tela de progresso
  const ProgressScreen = () => {
    const thisWeekWorkouts = workoutHistory.filter(w => {
      const workoutDate = new Date(w.date);
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return workoutDate >= weekAgo;
    });

    const thisMonthWorkouts = workoutHistory.filter(w => {
      const workoutDate = new Date(w.date);
      const monthAgo = new Date();
      monthAgo.setDate(monthAgo.getDate() - 30);
      return workoutDate >= monthAgo;
    });

    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Meu Progresso</h1>

        {/* Estatísticas principais */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{workoutHistory.length}</div>
              <div className="text-sm text-gray-600">Total de Treinos</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{thisWeekWorkouts.length}</div>
              <div className="text-sm text-gray-600">Esta Semana</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{thisMonthWorkouts.length}</div>
              <div className="text-sm text-gray-600">Este Mês</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{exercises.length}</div>
              <div className="text-sm text-gray-600">Total Exercícios</div>
            </CardContent>
          </Card>
        </div>

        {/* Histórico recente */}
        <Card>
          <CardHeader>
            <CardTitle>Treinos Recentes</CardTitle>
          </CardHeader>
          <CardContent>
            {workoutHistory.length > 0 ? (
              <div className="space-y-3">
                {workoutHistory.slice(-10).reverse().map((workout, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h3 className="font-semibold">{workout.workoutName}</h3>
                      <p className="text-sm text-gray-600">
                        {new Date(workout.date).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-blue-600">
                        {workout.duration || 30} min
                      </p>
                      <p className="text-xs text-gray-500">
                        {workout.exercises?.length || 0} exercícios
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <TrendingUp className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600">Nenhum treino registrado ainda</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  // Componente de detalhes do treino
  const WorkoutDetailScreen = () => {
    const [exerciseData, setExerciseData] = useState([]);
    const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
    const [showSetModal, setShowSetModal] = useState(false);
    const [currentSet, setCurrentSet] = useState({ weight: '', reps: '' });
    const [workoutStartTime, setWorkoutStartTime] = useState(null);

    useEffect(() => {
      if (currentWorkout?.exercises) {
        setExerciseData(currentWorkout.exercises.map(exercise => ({
          ...exercise,
          sets: [],
          completed: false,
        })));
      }
    }, [currentWorkout]);

    const startWorkout = () => {
      setIsWorkoutActive(true);
      setWorkoutStartTime(new Date());
      setCurrentExerciseIndex(0);
    };

    const finishWorkout = () => {
      const endTime = new Date();
      const duration = Math.round((endTime - workoutStartTime) / 60000);

      const workoutSession = {
        id: Date.now(),
        workoutId: currentWorkout.id,
        workoutName: currentWorkout.name,
        date: endTime.toISOString(),
        duration,
        exercises: exerciseData.map(exercise => ({
          name: exercise.name,
          sets: exercise.sets,
          completed: exercise.completed,
        })),
      };

      setWorkoutHistory([...workoutHistory, workoutSession]);
      setIsWorkoutActive(false);
      alert(`Treino concluído! Você treinou por ${duration} minutos.`);
      setActiveTab('home');
    };

    const addSet = () => {
      if (!currentSet.weight || !currentSet.reps) {
        alert('Preencha peso e repetições');
        return;
      }

      const updatedData = [...exerciseData];
      updatedData[currentExerciseIndex].sets.push({
        weight: parseFloat(currentSet.weight),
        reps: parseInt(currentSet.reps),
        timestamp: new Date().toISOString(),
      });

      setExerciseData(updatedData);
      setCurrentSet({ weight: '', reps: '' });
      setShowSetModal(false);
    };

    const completeExercise = () => {
      const updatedData = [...exerciseData];
      updatedData[currentExerciseIndex].completed = true;
      setExerciseData(updatedData);

      if (currentExerciseIndex < exerciseData.length - 1) {
        setCurrentExerciseIndex(currentExerciseIndex + 1);
      } else {
        if (confirm('Todos os exercícios concluídos! Deseja finalizar o treino?')) {
          finishWorkout();
        }
      }
    };

    if (!currentWorkout) {
      return (
        <div className="text-center py-8">
          <p>Nenhum treino selecionado</p>
          <Button onClick={() => setActiveTab('workouts')} className="mt-4">
            Voltar aos Treinos
          </Button>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">{currentWorkout.name}</h1>
            <p className="text-gray-600">{currentWorkout.description}</p>
            {isWorkoutActive && (
              <p className="text-sm text-blue-600 mt-2">
                Exercício {currentExerciseIndex + 1} de {exerciseData.length}
              </p>
            )}
          </div>
          <Button variant="outline" onClick={() => setActiveTab('workouts')}>
            Voltar
          </Button>
        </div>

        {/* Exercícios */}
        <div className="space-y-4">
          {exerciseData.map((exercise, index) => (
            <Card 
              key={index} 
              className={`${
                isWorkoutActive && index === currentExerciseIndex 
                  ? 'border-blue-500 bg-blue-50' 
                  : exercise.completed 
                    ? 'border-green-500 bg-green-50' 
                    : ''
              }`}
            >
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{exercise.name}</h3>
                    <p className="text-gray-600">{exercise.description}</p>
                    {exercise.targetSets && (
                      <p className="text-sm text-blue-600">
                        Meta: {exercise.targetSets} séries x {exercise.targetReps} repetições
                      </p>
                    )}
                  </div>
                  {exercise.completed && (
                    <Badge className="bg-green-500">
                      <Trophy className="h-3 w-3 mr-1" />
                      Concluído
                    </Badge>
                  )}
                </div>

                {/* Séries realizadas */}
                {exercise.sets.length > 0 && (
                  <div className="mb-4">
                    <h4 className="font-medium mb-2">Séries realizadas:</h4>
                    <div className="space-y-1">
                      {exercise.sets.map((set, setIndex) => (
                        <div key={setIndex} className="text-sm bg-gray-100 p-2 rounded">
                          Série {setIndex + 1}: {set.weight}kg x {set.reps} reps
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Botões de ação durante o treino */}
                {isWorkoutActive && index === currentExerciseIndex && (
                  <div className="flex gap-2">
                    <Button onClick={() => setShowSetModal(true)}>
                      <Plus className="mr-2 h-4 w-4" />
                      Adicionar Série
                    </Button>
                    {exercise.sets.length > 0 && (
                      <Button onClick={completeExercise} variant="outline">
                        <Trophy className="mr-2 h-4 w-4" />
                        Concluir Exercício
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Botão de ação principal */}
        <div className="flex justify-center">
          {!isWorkoutActive ? (
            <Button onClick={startWorkout} size="lg" className="w-full max-w-md">
              <Play className="mr-2 h-5 w-5" />
              Iniciar Treino
            </Button>
          ) : (
            <Button 
              onClick={() => {
                if (confirm('Tem certeza que deseja finalizar o treino?')) {
                  finishWorkout();
                }
              }}
              variant="destructive" 
              size="lg" 
              className="w-full max-w-md"
            >
              Finalizar Treino
            </Button>
          )}
        </div>

        {/* Modal para adicionar série */}
        <Dialog open={showSetModal} onOpenChange={setShowSetModal}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Série</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="weight">Peso (kg)</Label>
                <Input
                  id="weight"
                  type="number"
                  value={currentSet.weight}
                  onChange={(e) => setCurrentSet({ ...currentSet, weight: e.target.value })}
                  placeholder="0"
                />
              </div>
              <div>
                <Label htmlFor="reps">Repetições</Label>
                <Input
                  id="reps"
                  type="number"
                  value={currentSet.reps}
                  onChange={(e) => setCurrentSet({ ...currentSet, reps: e.target.value })}
                  placeholder="0"
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setShowSetModal(false)} className="flex-1">
                  Cancelar
                </Button>
                <Button onClick={addSet} className="flex-1">
                  Salvar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-6">
            <TabsTrigger value="home" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              Início
            </TabsTrigger>
            <TabsTrigger value="workouts" className="flex items-center gap-2">
              <Dumbbell className="h-4 w-4" />
              Treinos
            </TabsTrigger>
            <TabsTrigger value="exercises" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Exercícios
            </TabsTrigger>
            <TabsTrigger value="water" className="flex items-center gap-2">
              <Droplets className="h-4 w-4" />
              Água
            </TabsTrigger>
            <TabsTrigger value="progress" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Progresso
            </TabsTrigger>
          </TabsList>

          <TabsContent value="home">
            <HomeScreen />
          </TabsContent>

          <TabsContent value="workouts">
            <WorkoutsScreen />
          </TabsContent>

          <TabsContent value="exercises">
            <ExercisesScreen />
          </TabsContent>

          <TabsContent value="water">
            <WaterScreen />
          </TabsContent>

          <TabsContent value="progress">
            <ProgressScreen />
          </TabsContent>

          <TabsContent value="workout-detail">
            <WorkoutDetailScreen />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default App;

